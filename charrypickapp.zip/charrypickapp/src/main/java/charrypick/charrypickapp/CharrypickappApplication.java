package charrypick.charrypickapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CharrypickappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CharrypickappApplication.class, args);
	}

}
